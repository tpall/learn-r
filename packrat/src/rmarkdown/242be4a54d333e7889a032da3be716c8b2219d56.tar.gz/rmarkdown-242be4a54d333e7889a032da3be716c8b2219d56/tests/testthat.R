library(testthat)
test_check("rmarkdown")

